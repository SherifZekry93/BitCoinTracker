//
//  ViewController.swift
//  BitCoinTracker
//
//  Created by Sherif  Wagih on 7/3/18.
//  Copyright © 2018 Sherif Wagih. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
class ViewController: UIViewController,UIPickerViewDelegate,UIPickerViewDataSource {
    let baseURL = "https://apiv2.bitcoinaverage.com/indices/global/ticker/BTC"
    let currencyArray = ["AUD", "BRL","CAD","CNY","EUR","GBP","HKD","IDR","ILS","INR","JPY","MXN","NOK","NZD","PLN","RON","RUB","SEK","SGD","USD","ZAR"]
    var finalURL = "";
    //adhering to protocols
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1;
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return currencyArray.count;
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return currencyArray[row];
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        finalURL = baseURL + currencyArray[row]
        getData(numberOfCurrentRow: row);
    }
    @IBOutlet weak var currencyPicker: UIPickerView!
    @IBOutlet weak var priceLabel: UILabel!
    
    func getData(numberOfCurrentRow : Int)
    {
        Alamofire.request(finalURL, method: .get).responseJSON{
            response in
            if response.result.isSuccess
            {
                //print(response.result.value!)
                let result : JSON = JSON(response.result.value!);
                let doublevalue = result["ask"].double;
                self.priceLabel.text = "1 bitcoin = \(doublevalue!) " + self.currencyArray[numberOfCurrentRow];
            }
        }
    }
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        currencyPicker.delegate = self;
        currencyPicker.dataSource = self;
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

